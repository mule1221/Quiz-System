package com.newfile.quizsystem; 

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*; 

public class QuizSystem {
public static void main(String[] args) {
//File Paths
     String filename_J = "C:\\Users\\Mohammed\\Desktop\\QUESTION_JAVA.txt";
     String choise_J = "C:\\Users\\Mohammed\\Desktop\\MCQ_JAVA.txt";
     String filename_D = "C:\\Users\\Mohammed\\Desktop\\QUESTION_DSA.txt";
     String choise_D = "C:\\Users\\Mohammed\\Desktop\\MCQ_DSA.txt";
     String filename_B = "C:\\Users\\Mohammed\\Desktop\\QUESTION_BASE.txt";
     String choise_B = "C:\\Users\\Mohammed\\Desktop\\MCQ_BASE.txt";
     
  QuestionLoader reader1 = new ShortAnswerLoader();
  QuestionLoader reader2 = new ChoiceLoader();
 
  ArrayList<Question> shortquestion_J;
  ArrayList<Question> choicequestion_J;
  ArrayList<Question> shortquestion_D;
  ArrayList<Question> choicequestion_D;
  ArrayList<Question> shortquestion_B;
  ArrayList<Question> choicequestion_B;

  shortquestion_J = reader1.load(filename_J);
  choicequestion_J = reader2.load(choise_J);
  shortquestion_D = reader1.load(filename_D);
  choicequestion_D = reader2.load(choise_D);
  shortquestion_B = reader1.load(filename_B);
  choicequestion_B = reader2.load(choise_B);
 
 Scanner s = new Scanner(System.in);
 
 int choice ;
 
 do{
System.out.println("ENTER YOUR CHOICE:");
System.out.println("1. JAVA Questions");
System.out.println("2. DSA Questions");
System.out.println("3. DATABASE Questions");

    String subjectName; 
    choice = s.nextInt();
    
switch (choice) {
case 1:
  
  subjectName = "JAVA QUIZ";
  QuizManager.startQuiz(subjectName, shortquestion_J);
  QuizManager.startQuiz(subjectName, choicequestion_J);

break;
 case 2:
 
   subjectName = "DSA QUIZ";
  QuizManager.startQuiz(subjectName, shortquestion_D);
  QuizManager.startQuiz(subjectName, choicequestion_D);
  
 break;
case 3:
  
  subjectName = "DATABASE QUIZ";
  QuizManager.startQuiz(subjectName, shortquestion_B);
  QuizManager.startQuiz(subjectName, choicequestion_B);
  
 break;
default:
 System.out.println("INVALID INPUT");
} 
 }

      while (choice<1||choice>3);


 }
}