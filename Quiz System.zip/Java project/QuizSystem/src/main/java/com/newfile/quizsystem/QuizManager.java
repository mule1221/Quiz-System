package com.newfile.quizsystem;

import java.util.ArrayList;
import java.util.Scanner;


class QuizManager {

 public static void startQuiz(String title, ArrayList<Question> questions) {
 if (questions.isEmpty()) {
 System.out.println("No questions found for " + title);
 return;
 } 

 Scanner sc = new Scanner(System.in);
 int score = 0;
 System.out.println("\n===== " + title + " START ====="); 

 int i = 0;

 while (i < questions.size()) 
 {
 
     Question q = questions.get(i);
  
     System.out.println("Q" + (i + 1) + ": " + q.getQuestion());
     System.out.print("Your answer (type 'skip' or 'prev'): ");
 
     String userAnswer = sc.nextLine(); 
     
     if(userAnswer.equalsIgnoreCase("skip")){
         i++;
         continue;
     }

     if(userAnswer.equalsIgnoreCase("prev")){
         if(i > 0){
             i--;
         }
         continue;
     }

 if (userAnswer.equalsIgnoreCase(q.getAnswer())) {
 System.out.println("Correct!\n");
 score++;
 } else {
 System.out.println("Wrong! Correct answer: " + q.getAnswer() + "\n");
 }

 i++;
 }

     
 System.out.println("===== " + title + " END =====");
 System.out.println("Final Score: " + score + "/" + questions.size() + "\n");
}
}