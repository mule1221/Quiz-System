package com.newfile.quizsystem;
  


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

class Question {
 private String question;
 private String answer; 

public Question(String question, String answer) {
this.question = question;
this.answer = answer;
} 

public String getQuestion() { return question; }
public String getAnswer() { return answer; }
} 

interface QuestionLoader {
   ArrayList<Question> load(String path);
}
class ShortAnswerLoader implements QuestionLoader {
 @Override
public ArrayList<Question> load(String filename) {
    
ArrayList<Question> list = new ArrayList<>();

try  {
     BufferedReader br = new BufferedReader(new FileReader(filename));
     String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split("\\|");
             if (parts.length == 2) {
                 
             list.add(new Question(parts[0], parts[1]));
              
             }
         }
        
        br.close();
        
     } 
         catch (IOException e) 
         {
            System.out.println("Error reading file: " + filename);
         }

        return list;
        
    }
} 

class ChoiceLoader implements QuestionLoader {
 @Override
 public ArrayList<Question> load(String filename) {
     
 ArrayList<Question> list = new ArrayList<>();
 
 try  {
      BufferedReader br = new BufferedReader(new FileReader(filename));
      String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                 if (parts.length == 6) {
                    String q = parts[0];
                    String A = parts[1];
                    String B=  parts[2];
                    String C=  parts[3];
                    String D=  parts[4];
                    String a=  parts[5];
                    
                    String fullQuestion = q + "\n"
                           + "A. " + A + "\n"
                           + "B. " + B + "\n"
                           + "C. " + C + "\n"
                           + "D. " + D;
 
                    list.add(new Question(fullQuestion, a));
                         
                     }
             }
            
            br.close();
            
     } 
     
     catch (IOException e) {
         System.out.println("Error reading MCQ file.");
         }
 
      return list;
      
     }
} 

